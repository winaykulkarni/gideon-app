To log in:

- Email: admin@gideonapp.com
- Password: demopass


