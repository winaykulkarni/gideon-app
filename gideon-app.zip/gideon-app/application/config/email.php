<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	
	$config = [
		'mailtype' => 'html', 'crlf' => "\r\n",
		'newline' => "\r\n",
		'wordwrap' => TRUE
	];
        
        
/*defined('BASEPATH') OR exit('No direct script access allowed');
	
	$config = [
		'mailtype' => 'html', 'crlf' => "\r\n",
		'newline' => "\r\n",
		'protocol' => 'smtp',
		'smtp_host' => 'ssl://smtp.googlemail.com',
		'smtp_port' => 465,
		'smtp_user' => 'amirsanni@gmail.com',
		'smtp_pass' => 'ibadangolfclub2016',
		'charset' => 'iso-8859-1',
		'wordwrap' => TRUE
	];*/