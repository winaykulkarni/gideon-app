<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-05 00:52:15 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:52:15 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:52:15 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:52:15 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:53:09 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:53:09 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:53:21 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:53:21 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:53:21 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:53:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-11-05 00:53:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
ERROR - 2020-11-05 00:53:53 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:53:53 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:54:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-11-05 00:54:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
ERROR - 2020-11-05 00:54:53 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:54:53 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:54:53 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:54:58 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:54:58 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:16 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:16 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:30 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:30 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:34 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:34 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:40 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:40 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:40 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:40 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:50 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:50 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:50 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:51 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:57 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:55:57 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:57:17 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:57:17 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:57:17 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:57:17 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:35 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:35 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:35 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:35 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:48 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:48 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:48 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:58:49 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:59:09 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:59:09 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:59:12 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:59:12 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:59:12 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 00:59:12 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 01:00:34 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 01:00:34 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-05 01:12:32 --> 404 Page Not Found: Public/images
