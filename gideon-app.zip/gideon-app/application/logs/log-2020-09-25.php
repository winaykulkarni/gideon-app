<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-25 11:54:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-09-25 11:54:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
ERROR - 2020-09-25 11:54:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-09-25 11:54:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
ERROR - 2020-09-25 11:56:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-09-25 11:56:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
ERROR - 2020-09-25 12:01:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-09-25 12:01:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
