<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-04 19:15:08 --> 404 Page Not Found: Indexphp/index.php
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-04 19:15:08 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-04 19:15:08 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-04 19:15:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-11-04 19:15:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
ERROR - 2020-11-04 19:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 55
ERROR - 2020-11-04 19:16:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\gideon-app\application\controllers\Administrators.php 71
ERROR - 2020-11-04 19:16:20 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-04 19:16:20 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-04 19:17:52 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-04 19:17:52 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-04 19:17:52 --> 404 Page Not Found: Indexphp/index.php
ERROR - 2020-11-04 19:17:52 --> 404 Page Not Found: Indexphp/index.php
