<?php
defined('BASEPATH') OR exit('');
?>
<?php if($allTransInfo):?>
<?php $sn = 1; ?>
<div id="transReceiptToPrint">
    <div class="row">

        <div class="col-xs-12 text-right">
            <center style='margin-bottom:5px;float:right'><img src="<?=base_url()?>public/images/invoice-logo.JPG" alt="logo" class="img-responsive" ></center>
        </div>
        <div class="col-xs-12 text-right">
            <label>Receipt No:</label>
            <span><?=isset($ref) ? $ref : ""?></span>
        </div>
        <div class="col-xs-6">
            <div class="row margin-top-5">
                <div class="col-xs-12">
                    <b>Customer Name: <?=$cust_name?></b>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <b>Customer Phone: <?=$cust_phone?></b>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <b>Customer Email: <?=$cust_email?></b>
                </div>
            </div>
        </div>


        <div class="col-xs-6 text-right text-uppercase">
            
            <b>1410 Store, plot 5, block 2</b>
            <div>+234 7086201801, +234 7030167606</div>
            <b><?=isset($transDate) ? date('jS M, Y h:i:sa', strtotime($transDate)) : ""?></b>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <h4><b>Receiptx`</b></h4>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat
            </p>
        </div>
    </div>

    <br>
    
	<div class="row" style='font-weight:bold;background-color: grey;color: white;padding-top:5px;padding-bottom:5px;'>
		<div class="col-xs-4">Item</div>
		<div class="col-xs-4">QtyxPrice</div>
		<div class="col-xs-4">Tot(&#8358;)</div>
	</div>
	<hr style='margin-top:2px; margin-bottom:0px'>
    <?php $init_total = 0; ?>
    <?php foreach($allTransInfo as $get):?>
        <div class="row"  style="padding-top:5px;padding-bottom:5px;">
            <div class="col-xs-4"><b><?=ellipsize($get['itemName'], 10);?></b>
                <br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </div>
            <div class="col-xs-4"><?=$get['quantity'] . "x" .number_format($get['unitPrice'], 2)?></div>
            <div class="col-xs-4"><?=number_format($get['totalPrice'], 2)?></div>
        </div>
        <?php $init_total += $get['totalPrice'];?>
    <?php endforeach; ?>
    <hr style='margin-top:2px; margin-bottom:0px'>       
    <div class="row" style="padding-top:5px;padding-bottom:5px;">
        <div class="col-xs-12 text-right">
            <b>Total: &#8358;<?=isset($init_total) ? number_format($init_total, 2) : 0?></b>
        </div>
    </div>
    <hr style='margin-top:2px; margin-bottom:0px'>      
    <div class="row" style="padding-top:5px;padding-bottom:5px;">
        <div class="col-xs-12 text-right">
            <b>Discount(<?=$discountPercentage?>%): &#8358;<?=isset($discountAmount) ? number_format($discountAmount, 2) : 0?></b>
        </div>
    </div>       
    <div class="row" style="padding-top:5px;padding-bottom:5px;">
        <div class="col-xs-12 text-right">
            <?php if($vatPercentage > 0): ?>
            <b>VAT(<?=$vatPercentage?>%): &#8358;<?=isset($vatAmount) ? number_format($vatAmount, 2) : ""?></b>
            <?php else: ?>
            VAT inclusive
            <?php endif; ?>
        </div>
    </div>      
    <div class="row" style="padding-top:5px;padding-bottom:5px;">
        <div class="col-xs-12 text-right">
            <b>FINAL TOTAL: &#8358;<?=isset($cumAmount) ? number_format($cumAmount, 2) : ""?></b>
        </div>
    </div>
    <hr style='margin-top:5px; margin-bottom:0px'>
    <div class="row margin-top-5">
        <div class="col-xs-12">
            <b>Mode of Payment: <?=isset($_mop) ? str_replace("_", " ", $_mop) : ""?></b>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <b>Amount Tendered: &#8358;<?=isset($amountTendered) ? number_format($amountTendered, 2) : ""?></b>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <b>Change: &#8358;<?=isset($changeDue) ? number_format($changeDue, 2) : ""?></b>
        </div>
    </div>
    <hr style='margin-top:5px; margin-bottom:0px'>

    <br>

    <div class="row">
        <div class="col-xs-12">
            <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
            </small>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-xs-4">
            <small>System Info Tech</small></br>
            <small>River Street</small></br>
            <small>51222 Berlin</small></br>
            <small>North America.</small></br>
        </div>
        <div class="col-xs-4">
            <small>Ametsgerchit</small></br>
            <small>Register</small></br>
            <small>Mail:employer@gmail.com</small></br>
            <small>Tel: 9090909090</small></br>
        </div>
        <div class="col-xs-4">
            <small>Inhaber: Manager</small></br>
            <small>IBAN: DE4646544553</small></br>
            <small>BIC: LGHYKFTER</small></br>
            <small>St.Nr: 909334358884</small></br>
        </div>                
    </div>
</div>
<br class="hidden-print">
<div class="row hidden-print">
    <div class="col-sm-12">
        <div class="text-center">
            <button type="button" class="btn btn-primary ptr">
                <i class="fa fa-print"></i> Print Receipt
            </button>

           <!--  <button type="button" class="btn btn-primary " id="clickbind">
                <i class="fa fa-print"></i> Download PDF
            </button> -->
            
            <button type="button" data-dismiss='modal' class="btn btn-danger">
                <i class="fa fa-close"></i> Close
            </button>
        </div>
    </div>
</div>
<br class="hidden-print">



<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.min.js"></script>

<script>
function onClick() {
  var pdf = new jsPDF('p', 'pt', 'letter');
  pdf.canvas.height = 72 * 11;
  pdf.canvas.width = 72 * 8.5;

 // alert(document.getElementById("transReceiptModal").innerHTML);

  pdf.fromHTML(document.getElementById("transReceiptModal").innerHTML);

  pdf.save('test.pdf');
};

var element = document.getElementById("clickbind");
element.addEventListener("click", onClick);

</script>
<?php endif;?>